package com.example.flutter_with_db1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
