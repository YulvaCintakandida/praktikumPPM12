class Mahasiswa {
  final String nim;
  final String nama;
  final String gender;
  final String prodi;
  final String alamat;

  Mahasiswa(
      {required this.nim,
      required this.nama,
      required this.gender,
      required this.prodi,
      required this.alamat});
}